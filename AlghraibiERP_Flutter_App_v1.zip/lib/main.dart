import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const AlghraibiERP());
}

class AlghraibiERP extends StatelessWidget {
  const AlghraibiERP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Alghraibi ERP',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const LoginScreen(),
    );
  }
}