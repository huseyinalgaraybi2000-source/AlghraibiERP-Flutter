import 'package:flutter/material.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          child: const Text('دخول إلى النظام'),
          onPressed: () {
            Navigator.push(context,
              MaterialPageRoute(builder: (_) => const DashboardScreen()));
          },
        ),
      ),
    );
  }
}