import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = ['العملاء','المخزون','المبيعات','المشتريات','الفواتير','التقارير'];
    return Scaffold(
      appBar: AppBar(title: const Text('Alghraibi ERP')),
      body: GridView.count(
        crossAxisCount: 2,
        children: items.map((e)=>Card(child: Center(child: Text(e)))).toList(),
      ),
    );
  }
}